const KEY_USER="users";
function saveUser(user){
    //load the old data
    let data=readUsers();
    //merge
    data.push(user);
    //save the user in the localstorage
    let val=JSON.stringify(data);
    localStorage.setItem(KEY_USER,val);
}
function readUsers(){
    let perviousUsers=localStorage.getItem(KEY_USER);
    if(!perviousUsers){ //Not data?
        return [];//create an empty array
    }else{
        let list =JSON.parse(perviousUsers); //parse the string back into obj
        return list; //this is an object
    }
}
